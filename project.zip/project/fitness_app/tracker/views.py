# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from .forms import PreferenceForm, LoginForm
from .models import UserPreference

def set_preferences(request):
    if request.method == "POST":
        form = PreferenceForm(request.POST)
        if form.is_valid():
            response = redirect('home')
            response.set_cookie('workout_intensity', form.cleaned_data['workout_intensity'], max_age=3600)
            response.set_cookie('preferred_exercises', form.cleaned_data['preferred_exercises'], max_age=3600)
            return response
    else:
        form = PreferenceForm()
    return render(request, 'tracker/set_preferences.html', {'form': form})

def home(request):
    workout_intensity = request.COOKIES.get('workout_intensity', 'medium')
    preferred_exercises = request.COOKIES.get('preferred_exercises', 'Push-ups, Squats')
    return render(request, 'tracker/home.html', {
        'workout_intensity': workout_intensity,
        'preferred_exercises': preferred_exercises
    })

def user_login(request):
    if request.method == "POST":
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            response = redirect('home')
            if form.cleaned_data.get('remember_me'):
                request.session.set_expiry(1209600)  # 2 weeks
            else:
                request.session.set_expiry(0)  # Browser session only
            return response
    else:
        form = LoginForm()
    return render(request, 'tracker/login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('login')
