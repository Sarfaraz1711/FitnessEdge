from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class UserPreference(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    workout_intensity = models.CharField(max_length=50, default='medium')
    preferred_exercises = models.TextField(default='Push-ups, Squats')

    def __str__(self):
        return self.user.username
