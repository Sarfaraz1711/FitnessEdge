from django import forms
from django.contrib.auth.forms import AuthenticationForm

class PreferenceForm(forms.Form):
    workout_intensity = forms.ChoiceField(choices=[('low', 'Low'), ('medium', 'Medium'), ('high', 'High')])
    preferred_exercises = forms.CharField(widget=forms.Textarea)

class LoginForm(AuthenticationForm):
    remember_me = forms.BooleanField(required=False, label="Remember Me")
